#ifndef __NC_STRINGS__H
#define __NC_STRINGS__H

// ---------------------------------------------------------------------------|
namespace YumaTest
{

// ---------------------------------------------------------------------------|
extern const char* NC_SSH_END;      ///< SSH End of session indication

} // namespace YumaTest

#endif // __NC_STRINGS__H
