netconf
=======

Fork of the defacto standard Yuma project since it went proprietary.  Netconf is a management protocol (similar to SNMP) defined in RFC4741.
