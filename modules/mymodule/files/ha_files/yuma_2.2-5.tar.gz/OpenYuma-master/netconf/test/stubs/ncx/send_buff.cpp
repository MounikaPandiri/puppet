#include "send_buff.h"

// ---------------------------------------------------------------------------|
status_t send_buff (int fd, const char *buffer, size_t cnt)
{
    // TODO: Store input parameters for checking
    fd = fd;
    buffer = buffer;
    cnt = cnt;

    // TODO: Make return value configurable, via a std::queue
    return NO_ERR;
}

